public class Pattern_64
{
	public static void main(String x[])
	{
		for(int i=1;i<=10;i++)
		{
			for(int j=1;j<=9;j++)
			{
				
				System.out.print("*");
			}
			System.out.println();
		}
	}
}