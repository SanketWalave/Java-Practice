public class Pattern_75
{
	public static void main(String x[])
	{
		for(int i=1;i<=6;i++)
		{
			
		}
	}
}