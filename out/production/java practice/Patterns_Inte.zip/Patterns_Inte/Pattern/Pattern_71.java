public class 
{
	public static void main(String x[])
	{
		
	}
}