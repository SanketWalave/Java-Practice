public class Pattern_7
{
	
    public static void main(String x[])
	{
		for(int i=1;i<=3;i++)
		{
			for(int j=1;j<=5;j++)
			{
				System.out.printf("*");
			}
			System.out.print("\n");
		}
	}
}