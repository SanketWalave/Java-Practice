class Stud_lib
{
	private String studentname;
	private String studemail;
	public void setStudName(String studentname)
	{
		this.studentname=studentname;
	}
	public void setStudemail(String studemail)
	{
		this.studemail=studemail;
	}
	public String getStudName()
	{
		return studentname;
	}
	public String getStudemail()
	{
		return studemail;
	}
	
}